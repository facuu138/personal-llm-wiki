---
name: lint
description: Check the wiki for problems and report them. Use when I say "lint", "check the wiki", or "health check".
---

# Lint

Report only. Never change any file.

## 1. Mechanical checks

Run `bash .claude/scripts/lint.sh`. It checks:
- Sources not yet ingested.
- Broken links.
- Wiki pages missing from `wiki/index.md`.
- Records with empty required fields, or a `project` not in SCHEMA.md.
- File names that do not follow `YYYY-MM-DD-short-slug.<ext>`.
- A leftover `.claude/ingest-running` marker.

## 2. Judgment checks

Read the wiki and the records. Look for:
- Statements without a source link.
- Contradictions not yet in `wiki/open-questions.md`.
- Decisions shown as current that a later decision replaced.
- Open questions that a later record already answers.

## 3. Report

List problems by type, with file names.
For each, say how to fix it:
- Wiki problems: add a note with `/add`, then run `/ingest`.
- Record problems: I can fix these myself, or you can fix them if I ask.
- A leftover marker: I can delete it, or you can if I ask.
