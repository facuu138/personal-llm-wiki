---
name: ingest
description: Compile pending sources from raw/ and records/ into the wiki, the TODO board, and IDEAS.md, after my approval. Use after /add, when I say "ingest", or when I ask to update the wiki.
argument-hint: "[file paths to re-ingest]"
---

# Ingest

The only way to change `wiki/` and `log/`.
SCHEMA.md says what ingest does. This skill says in what order, and when to ask me.

## 1. Find pending sources

Run `bash .claude/scripts/pending-sources.sh`. It lists every file in `raw/` and `records/` that no file in `log/` mentions.
If I name files, treat them as pending too, even if the log mentions them.

For a file that was ingested before:
- Update its existing record instead of creating a new one.
- In the plan, show which wiki statements change or disappear because of the new version.
- Do not add cards or ideas that are already in `TODO.md` or `IDEAS.md`.

If nothing is pending, tell me the wiki is up to date and stop.

If more than 10 sources are pending, work in batches:
- Sort them by date, oldest first. Later sources can replace earlier ones, so order matters.
- Take the oldest 5 to 10. Keep revisions of the same meeting in the same batch.
- Run steps 2 to 5 for that batch only. Then tell me how many sources are left, and ask whether to continue with the next batch.

## 2. Check scope

Read each pending source.
If one is out of scope, leave it out and tell me why.

## 3. Plan

Read the wiki pages the sources touch. Then show me a plan. Write nothing yet.

- Renames: pending files whose names do not follow `YYYY-MM-DD-short-slug.<ext>`.
- Records to create or update: type, title, project, and the raw file each comes from.
- Wiki pages to create or update: the facts to add or change, and the source of each fact.
- Conflicts to add to `wiki/open-questions.md`, and open questions to move to Resolved.
- Cards to add to the Automated column of `TODO.md`.
- Ideas to add to `IDEAS.md`.

Then ask me: Approve, Change, or Cancel.
- Change: revise the plan and ask again.
- Cancel: stop. Nothing has changed.

## 4. Write

First run `touch .claude/ingest-running`. Without this file, the hook blocks every change to `wiki/`, `log/`, and `TODO.md`.
Do exactly the approved plan, following SCHEMA.md. Add nothing else.
Do the renames first, so every link uses the final names.
If a wiki page that SCHEMA.md lists does not exist yet, create it.

## 5. Log and report

Write the log file, as SCHEMA.md describes.
Then run `rm -f .claude/ingest-running`. Also remove it if anything fails.
Tell me in a few lines what changed, with links to the pages that changed.
