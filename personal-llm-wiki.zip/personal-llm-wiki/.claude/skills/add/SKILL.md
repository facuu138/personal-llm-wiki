---
name: add
description: Save new information to the wiki. Handles typed notes, pasted text, files and PDFs, meeting notes, decisions, and notes already in the vault. Use when I give you something to keep, or say "add", "save this", or "log this".
argument-hint: "<text, file path, or note name>"
---

# Add

Follow CLAUDE.md and SCHEMA.md.
This skill only saves things. It never changes `wiki/`, `log/`, `TODO.md`, or `IDEAS.md`.

## 1. Check scope

If the content is out of scope, tell me and stop.

## 2. Choose where it goes

- Text I write after `/add`, in my own words: create a record.
  Pick the type from the content: meeting, decision, or note if unsure.
  Keep my words in the body, then fill in the frontmatter.
- Text I paste from elsewhere (an email, a chat, a transcript): save it unchanged in `raw/` as `.md`, with one first line: date, people, and where it came from.
- A file, such as a PDF: save it unchanged in `raw/`.
- An image or attachment: `raw/attachments/`.
- A file from outside the vault: copy it into `raw/`. Leave the original where it is.
- A note that already uses a template, with frontmatter and a `type`: `records/<type>/`.

If you cannot tell whether text is mine or copied, ask me.

## 3. Name it

Use `YYYY-MM-DD-short-slug.<ext>`, with the date of the event.
Take the date from the frontmatter or the content. If the date is unclear, ask me.

## 4. Check records

For a record, check the required fields in SCHEMA.md: `type`, `title`, `date`, `project`, `sources`.
If one is empty and the content does not answer it, ask me.
`project` must be a name from the Projects table in SCHEMA.md.

## 5. Notes already in the vault

- Move the note. Do not copy it.
- Only move loose notes. Never move anything in `raw/`, `records/`, `wiki/`, `log/`, or `templates/`, or the files `TODO.md`, `IDEAS.md`, `CLAUDE.md`, and `SCHEMA.md`.
- Search the vault for links to the old file name. If you find any, list them for me.

## 6. Report

Tell me in one or two lines what you saved and where.
Then ask whether to run `/ingest` now or later.
