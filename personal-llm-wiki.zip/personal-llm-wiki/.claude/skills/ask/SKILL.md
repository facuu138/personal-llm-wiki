---
name: ask
description: Answer a question from the wiki, with links to sources. Use for any question about my work, projects, people, decisions, tasks, or ideas.
argument-hint: "<question>"
---

# Ask

Read only. Never change any file.

1. Read `wiki/index.md`, then the pages that apply.
2. Read the records and raw files those pages cite, to confirm details.
3. For questions about tasks, read `TODO.md`. For questions about ideas, read `IDEAS.md`.
4. If the wiki has no answer, search `records/` and `raw/`. Say the answer is not in the wiki yet.
5. Answer directly first, in a few sentences. Link every fact to its source.
   If sources disagree, show both. If information is missing, say so. Never guess.
6. If the answer combines several sources in a useful way, offer to save it as a note with `/add`.
