---
name: setup
description: Set up a new wiki from this template. Fills in every <FILL> placeholder in CLAUDE.md and SCHEMA.md. Use once, when I say "setup", "set up the wiki", or when CLAUDE.md still has <FILL> placeholders.
---

# Setup

Run this once, on a fresh copy of the template.
It only changes `CLAUDE.md` and `SCHEMA.md`.

## 1. Check

Search `CLAUDE.md` and `SCHEMA.md` for `<FILL:`.
If none are left, tell me the wiki is already set up and stop.

## 2. Ask

Ask me, in one message:
- The wiki's name.
- What the wiki is about, and my role in it.
- The projects to track. For each: a short lowercase slug and one line on what it is.
- What is in scope, beyond projects, people, and decisions.
- What is out of scope.
- What sensitive data must never be stored.
- Whether I import meeting notes with a script. If not, you will remove "Imported meetings" from `SCHEMA.md`.

## 3. Write

Replace every `<FILL: ...>` with my answers.
Write plainly: short sentences, one idea per sentence.
In `SCHEMA.md`, write one row per project in the Projects table. Keep `general` and `misc`.
Remove the "Not set up yet?" line from `CLAUDE.md`.
Change nothing else.

## 4. Report

Show me the Scope section and the Projects table.
Then tell me to start with `/add`.
