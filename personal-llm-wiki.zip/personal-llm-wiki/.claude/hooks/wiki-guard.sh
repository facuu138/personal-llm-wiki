#!/usr/bin/env bash
# Guards the wiki. Claude Code runs it and sends a JSON description of the action on stdin.
#   session-start  Clears a leftover ingest marker and reports pending sources.
#   pre-edit       Blocks edits to wiki/, log/, and TODO.md outside /ingest,
#                  and edits to files that already exist in raw/.
mode="${1:-}"
input=$(cat)
root="${CLAUDE_PROJECT_DIR:-$(pwd)}"
marker="$root/.claude/ingest-running"

# Turn text into a safe JSON string value.
esc() { awk 'BEGIN{ORS=""} {gsub(/\\/,"\\\\"); gsub(/"/,"\\\""); gsub(/\t/," "); if (NR>1) print "\\n"; print}'; }

deny() {
  printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s"}}\n' "$(printf '%s' "$1" | esc)"
  exit 0
}

case "$mode" in
  session-start)
    rm -f "$marker"
    pending=$(CLAUDE_PROJECT_DIR="$root" bash "$root/.claude/scripts/pending-sources.sh")
    if [ -n "$pending" ]; then
      msg="These sources are not in the wiki yet:
$pending
Tell me, and offer to run /ingest."
      printf '{"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":"%s"}}\n' "$(printf '%s' "$msg" | esc)"
    fi
    ;;

  pre-edit)
    path=$(printf '%s' "$input" | grep -oE '"(file_path|notebook_path)"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed -E 's/^[^:]*:[[:space:]]*"//; s/"$//')
    [ -z "$path" ] && exit 0
    case "$path" in /*) ;; *) path="$root/$path" ;; esac
    rel="${path#"$root"/}"
    [ "$rel" = "$path" ] && exit 0   # outside the vault: not our business

    case "$rel" in
      wiki/*|log/*|TODO.md)
        [ -f "$marker" ] || deny "Only /ingest can change $rel. To change the wiki, add a note with /add and run /ingest. To change the board, I do it in Obsidian."
        ;;
      raw/*)
        [ -e "$path" ] && deny "$rel is a raw source and cannot change after it is saved (rule 2). Add a new note with /add instead."
        ;;
    esac
    ;;
esac
exit 0
