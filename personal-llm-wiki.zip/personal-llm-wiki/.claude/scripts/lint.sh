#!/usr/bin/env bash
# Mechanical checks for the wiki. Report only; changes nothing.
# Exits 1 if it finds a problem.
cd "${CLAUDE_PROJECT_DIR:-$(dirname "$0")/../..}" || exit 2
n=0
say() { echo "  $1"; n=$((n + 1)); }
files() { find "$@" -type f ! -name '.*' -print0 2>/dev/null; }

echo "Sources not yet ingested:"
while IFS= read -r f; do [ -n "$f" ] && say "$f"; done < <(bash .claude/scripts/pending-sources.sh)

echo "Broken links:"
while IFS= read -r -d '' f; do
  d=$(dirname "$f")
  links=$(awk '/^[[:space:]]*```/{c=!c; next} !c' "$f" | sed 's/`[^`]*`//g' | grep -oE '\]\([^)]+\)' | sed -E 's/^\]\(//; s/\)$//')
  while IFS= read -r l; do
    [ -z "$l" ] && continue
    case "$l" in '<'*) l="${l#<}"; l="${l%%>*}" ;; *) l="${l%% *}" ;; esac
    case "$l" in http://*|https://*|mailto:*|'#'*) continue ;; esac
    t="${l%%#*}"; [ -z "$t" ] && continue
    t=$(printf '%b' "${t//%/\\x}")
    [ -e "$d/$t" ] || say "$f -> $l"
  done <<< "$links"
done < <(files wiki records log TODO.md IDEAS.md CLAUDE.md SCHEMA.md -name '*.md')

echo "Wiki pages missing from wiki/index.md:"
while IFS= read -r -d '' f; do
  [ "$f" = "wiki/index.md" ] && continue
  grep -qF "${f#wiki/}" wiki/index.md 2>/dev/null || say "$f"
done < <(files wiki -name '*.md')

echo "Records with missing fields or unknown project:"
projects=$(awk '/^## Projects/{p=1; next} /^## /{p=0} p' SCHEMA.md | grep -oE '^\| `[^`]+`' | sed -E 's/^\| `//; s/`$//')
while IFS= read -r -d '' f; do
  fm=$(awk 'NR==1 && !/^---/{exit} /^---/{c++; if (c==2) exit; next} c==1' "$f")
  for k in type title date project; do
    printf '%s\n' "$fm" | grep -qE "^$k:[[:space:]]*[^[:space:]]" || say "$f: empty $k"
  done
  printf '%s\n' "$fm" | grep -qE '^sources:' || say "$f: no sources field"
  p=$(printf '%s\n' "$fm" | sed -nE 's/^project:[[:space:]]*//p' | tr -d '"'"'" | sed 's/[[:space:]]*$//')
  [ -n "$p" ] && ! printf '%s\n' "$projects" | grep -qxF "$p" && say "$f: project '$p' is not in SCHEMA.md"
done < <(files records -name '*.md')

echo "File names not following YYYY-MM-DD-short-slug.ext:"
while IFS= read -r -d '' f; do
  b=$(basename "$f")
  printf '%s' "$b" | grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}-[a-z0-9]+(-[a-z0-9]+)*\.[A-Za-z0-9]+$' || say "$f"
done < <(files raw records log)

if [ -f .claude/ingest-running ]; then
  echo "Leftover ingest marker:"; say ".claude/ingest-running exists. The wiki guard is off until it is removed."
fi

echo "Problems found: $n"
[ "$n" -eq 0 ]
