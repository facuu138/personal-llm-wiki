#!/usr/bin/env bash
# Lists sources in raw/ and records/ that no file in log/ mentions.
# Prints nothing when every source has been ingested.
cd "${CLAUDE_PROJECT_DIR:-$(dirname "$0")/../..}" || exit 0
find raw records -type f \
  ! -path 'raw/attachments/*' ! -name '.*' 2>/dev/null |
  sort | while IFS= read -r f; do
    grep -rqF -- "$f" log/ 2>/dev/null || echo "$f"
  done
exit 0
