# Ideas

- 

## From notes

